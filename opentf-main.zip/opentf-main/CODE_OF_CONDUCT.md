# Code of Conduct

We follow the [CNCF Code of Conduct](https://github.com/cncf/foundation/blob/main/code-of-conduct.md).

<!-- TODO: Decide who will handle Code of Conduct reports and replace [INSERT EMAIL ADDRESS]
    with an email address in the paragraph below. We recommend using a mailing list to handle reports.
    If your project isn't prepared to handle reports, remove the project email address and just have
    reporters send to conduct@cncf.io.
-->
Please contact contact@opentf.org in order to report violations of the Code of Conduct.
