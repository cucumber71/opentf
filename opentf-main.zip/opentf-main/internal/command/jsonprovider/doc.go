// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package jsonprovider contains types and functions to marshal terraform
// provider schemas into a json formatted output.
package jsonprovider
