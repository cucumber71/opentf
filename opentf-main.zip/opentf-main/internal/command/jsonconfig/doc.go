// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package jsonconfig implements methods for outputting a configuration snapshot
// in machine-readable json format
package jsonconfig
