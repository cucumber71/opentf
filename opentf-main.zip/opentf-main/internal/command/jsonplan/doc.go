// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package jsonplan implements methods for outputting a plan in a
// machine-readable json format
package jsonplan
