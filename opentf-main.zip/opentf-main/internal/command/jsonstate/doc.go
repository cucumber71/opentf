// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package jsonstate implements methods for outputting a state in a
// machine-readable json format
package jsonstate
